-- ============================================================================
-- MyChat / Whatappero — Row Level Security fix
-- ============================================================================
-- Your repo has no schema/migration files, which means RLS policies were set
-- up by hand in the Supabase dashboard. The most common reason "create group"
-- and "create private chat" silently do nothing is that room_members only
-- has an INSERT policy allowing user_id = auth.uid() — which blocks adding
-- Luna (the AI bot) or an invited friend to the room, since those rows have
-- a user_id that ISN'T the current user.
--
-- Run this whole file once in the Supabase SQL editor
-- (Project -> SQL Editor -> New query). It's safe to re-run.
-- ============================================================================

-- Make sure RLS is on (it should already be, but this is harmless if so)
alter table public.rooms enable row level security;
alter table public.room_members enable row level security;
alter table public.messages enable row level security;
alter table public.profiles enable row level security;

-- ---------------------------------------------------------------------------
-- rooms
-- ---------------------------------------------------------------------------
drop policy if exists "rooms_select_member" on public.rooms;
create policy "rooms_select_member" on public.rooms
  for select using (
    exists (
      select 1 from public.room_members rm
      where rm.room_id = rooms.id and rm.user_id = auth.uid()
    )
  );

drop policy if exists "rooms_insert_own" on public.rooms;
create policy "rooms_insert_own" on public.rooms
  for insert with check (created_by = auth.uid());

-- ---------------------------------------------------------------------------
-- room_members
-- The key fix: allow a room's creator to add OTHER people (the AI bot,
-- an invited friend) to a room they created — not just themselves.
-- ---------------------------------------------------------------------------
drop policy if exists "room_members_select_member" on public.room_members;
create policy "room_members_select_member" on public.room_members
  for select using (
    user_id = auth.uid()
    or exists (
      select 1 from public.room_members rm2
      where rm2.room_id = room_members.room_id and rm2.user_id = auth.uid()
    )
  );

drop policy if exists "room_members_insert_self_or_creator" on public.room_members;
create policy "room_members_insert_self_or_creator" on public.room_members
  for insert with check (
    -- you're adding yourself...
    user_id = auth.uid()
    -- ...or you created the room, so you can add the AI bot / invited members
    or exists (
      select 1 from public.rooms r
      where r.id = room_members.room_id and r.created_by = auth.uid()
    )
  );

drop policy if exists "room_members_delete_self" on public.room_members;
create policy "room_members_delete_self" on public.room_members
  for delete using (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- messages
-- ---------------------------------------------------------------------------
drop policy if exists "messages_select_member" on public.messages;
create policy "messages_select_member" on public.messages
  for select using (
    exists (
      select 1 from public.room_members rm
      where rm.room_id = messages.room_id and rm.user_id = auth.uid()
    )
  );

drop policy if exists "messages_insert_member" on public.messages;
create policy "messages_insert_member" on public.messages
  for insert with check (
    sender_id = auth.uid()
    and exists (
      select 1 from public.room_members rm
      where rm.room_id = messages.room_id and rm.user_id = auth.uid()
    )
  );

-- Allow the AI bot's replies (sent via the server-side service-role key in
-- app/api/ai-reply/route.ts) to be inserted. The service role bypasses RLS
-- entirely, so this policy is mainly a safety net if you ever call this
-- with an anon/user key instead.
drop policy if exists "messages_insert_ai_bot" on public.messages;
create policy "messages_insert_ai_bot" on public.messages
  for insert with check (sender_id = '00000000-0000-0000-0000-000000000001');

-- ---------------------------------------------------------------------------
-- profiles
-- Needs to be readable by any logged-in user so username lookups (inviting
-- someone to a private chat / group) work.
-- ---------------------------------------------------------------------------
drop policy if exists "profiles_select_all" on public.profiles;
create policy "profiles_select_all" on public.profiles
  for select using (auth.role() = 'authenticated');

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own" on public.profiles
  for insert with check (id = auth.uid());

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update using (id = auth.uid());

-- ---------------------------------------------------------------------------
-- The AI bot needs its own profile row so it shows up correctly in
-- messages.profiles joins and satisfies any FK from room_members/messages.
-- ---------------------------------------------------------------------------
insert into public.profiles (id, username, full_name, avatar_url, is_bot)
values ('00000000-0000-0000-0000-000000000001', 'luna', 'Luna AI', null, true)
on conflict (id) do nothing;
